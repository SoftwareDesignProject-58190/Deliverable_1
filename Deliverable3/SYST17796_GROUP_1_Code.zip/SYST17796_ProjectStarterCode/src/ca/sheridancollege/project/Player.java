package ca.sheridancollege.project;

public class Player extends AbstractPlayer {
    public Player(String name) {
        super(name);
    }
}